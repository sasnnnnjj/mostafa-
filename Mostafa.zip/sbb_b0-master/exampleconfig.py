from sample_config import Config


class Development(Config):

    APP_ID = 
    
    API_HASH = ""

    ALIVE_NAME = ""

    DB_URI = ""

    STRING_SESSION = ""

    TG_BOT_TOKEN = ""

    PRIVATE_GROUP_BOT_API_ID = 

    COMMAND_HAND_LER = "."

    SUDO_COMMAND_HAND_LER = "."
